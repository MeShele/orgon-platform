// ============================================================
// ORGON · Crimson Ledger v2 — Landing
// ============================================================
// Полностью переписанная landing страница (P0 + P1):
//   - Hero без AI-slop декораций
//   - <TrustRow> — placeholder client logos + compliance badges
//   - <Pillars> с flagship-layout (navy 1/2 + 2 supporting 1/4)
//   - <Numbers> — KPI без mixed-units (M-of-N → 7-of-15)
//   - <FlowSection> — full navy block с TxFlow v2 (policy + ETA + audit)
//   - <BottomCTA> — full navy block, без border-l-4 accent
//   - Никаких иконок-декораций solar:*-bold; номера 01/02/03 + текст
// ============================================================

import Link from "next/link";
import { PublicHeader } from "@/components/layout/PublicHeader";
import { PublicFooter } from "@/components/layout/PublicFooter";
import { Hero } from "@/components/landing/Hero";
import { TrustRow } from "@/components/landing/TrustRow";
import { Pillars } from "@/components/landing/Pillars";
import { Numbers } from "@/components/landing/Numbers";
import { FlowSection } from "@/components/landing/FlowSection";
import { BottomCTA } from "@/components/landing/BottomCTA";

export default function HomePage() {
  return (
    <>
      <PublicHeader />
      <main>
        <Hero />
        <TrustRow />
        <Pillars />
        <Numbers />
        <FlowSection />
        <BottomCTA />
      </main>
      <PublicFooter />
    </>
  );
}
