# ORGON · Crimson Ledger v2 — Migration Guide

Этот пакет реализует **P0 + P1** правки из ревью.
Все файлы готовы под структуру `MeShele/orgon-platform`.

---

## Что внутри

```
orgon-p0p1/
├─ frontend/src/
│  ├─ app/
│  │  ├─ globals.css                          ← P0 #1: разделённые токены
│  │  └─ (public)/page.tsx                    ← новый landing root
│  └─ components/
│     ├─ landing/
│     │  ├─ Hero.tsx                          ← без AI-slop декора
│     │  ├─ TrustRow.tsx                      ← P1 #2: новая секция
│     │  ├─ Pillars.tsx                       ← P1 #3: flagship-layout
│     │  ├─ Numbers.tsx                       ← P0 #4: 7-of-15 + 5-й tile
│     │  ├─ FlowSection.tsx                   ← P0 #2 + P1 #5: navy + TxFlow v2
│     │  └─ BottomCTA.tsx                     ← P0 #2: navy без border-l
│     └─ layout/
│        ├─ PublicHeader.tsx
│        └─ PublicFooter.tsx                  ← P0 #5: legal + license
├─ preview/
│  └─ index.html                              ← интерактивный preview
└─ MIGRATION.md                               ← этот файл
```

---

## Порядок интеграции

### 1. Токены (5 минут, риск низкий)

Замените `frontend/src/app/globals.css` целиком.

**Breaking changes:**
- `--destructive` теперь ink-чёрный (`#1a1a1a`), не crimson.
  Если у вас были компоненты, опирающиеся на crimson-цвет
  destructive — они продолжат работать (visually distinct), но
  смысл изменится: «удалить» теперь визуально отделено от brand.
- `--accent-foreground` больше не crimson, теперь ink. Проверьте
  компоненты, использующие `bg-accent text-accent-foreground` —
  на скриншотах разница минимальна.
- `--ring` стал ink. Focus state по всему UI станет ink-outline,
  не crimson. Это правильно для institutional UI.
- Добавлены токены `--navy*` — используются на landing.

### 2. Landing (15 минут)

Замените файлы:
- `frontend/src/app/(public)/page.tsx`
- `frontend/src/components/layout/PublicHeader.tsx`
- `frontend/src/components/layout/PublicFooter.tsx`

Создайте новые:
- `frontend/src/components/landing/Hero.tsx`
- `frontend/src/components/landing/TrustRow.tsx`
- `frontend/src/components/landing/Pillars.tsx`
- `frontend/src/components/landing/Numbers.tsx`
- `frontend/src/components/landing/FlowSection.tsx`
- `frontend/src/components/landing/BottomCTA.tsx`

**Зависимости:** все эти файлы используют существующие компоненты:
- `@/components/ui/Button`
- `@/components/ui/primitives` (Eyebrow, BigNum, Mono, StatusPill)
- `@/components/brand/LogoMark` (не трогаем)

Если у вас primitives называются иначе — поправьте импорты.

### 3. Замена данных в TrustRow

`TrustRow.tsx` содержит **placeholder** клиенты:
```ts
TENGRI BANK · CRYPTOSTAN OÜ · SILK GATE · ALATAU CAPITAL
```
Замените на реальные пилотные интеграции, либо оставьте при
условии, что эти бренды действительно ваши пилотные клиенты.
Если нет — поменяйте на нейтральные «PILOT 01..04» до момента,
когда сможете назвать реальные.

### 4. Замена данных в PublicFooter (legal block)

Открыть `PublicFooter.tsx`, заменить:
- `ОсОО «АСИСТЕМ»` → реальное название юрлица
- `000000-0000-ООО` → реальный рег. номер
- `00000000000000` → реальный ИНН
- `КР, г. Бишкек, пр. Чуй, д. 0` → реальный адрес
- Email-домен `@orgon.kg` — если ещё не куплен, временно
  оставьте `@orgon.asystem.kg`, но это блокер для продаж.

---

## Что НЕ вошло (остаётся на P2)

- Token-sweep authenticated pages под Crimson Ledger density
  (25+ pages: /billing, /audit, /analytics, и т.д.)
- Mobile sidebar drawer
- Aceternity cleanup (AnimatedModal, HoverBorderGradient,
  SkeletonCard, ButtonHover на /analytics)
- HelpTooltip перевод на токены
- Удаление @keyframes spotlight
- KPI tiles на /dashboard — добавление delta % vs prev period
- Sparkline без оси Y → с явной % меткой

Все эти задачи зафиксированы в моём ревью (раздел 5, P2).

---

## Превью

Откройте `preview/index.html` в браузере — это интерактивный
снапшот всех landing-секций с переключателем light/dark.
Полностью статический HTML, без зависимостей.

---

## Контракты, которые НЕ менялись

- API контракты в `src/lib/api.ts` — не трогаются.
- Demo seed `013_demo_data.sql` + `014_wallet_labels.sql` — не трогаются.
- Theme persistence через cookie `orgon_theme` — не меняется.
- Default theme = light — не меняется.
- i18n структура — не меняется (но новые landing-копии
  пока inline на русском; если хотите i18n — выделите ключи в
  `frontend/src/i18n/locales/ru.json` под `landing.*` namespace,
  это часовая правка).

---

## Чек-лист после интеграции

- [ ] `globals.css` заменён, `pnpm dev` стартует без ошибок
- [ ] `/` рендерится: Hero → TrustRow → Pillars → Numbers → FlowSection → BottomCTA
- [ ] Light theme: focus-ring чёрный, не crimson
- [ ] Dark theme: navy секции читаются, brand crimson не мерцает
- [ ] Footer показывает юрлицо и статус лицензии
- [ ] Mobile (375px): hero одна колонка, demo-card снизу, navy секции читаются
- [ ] Lighthouse Performance ≥ 90 (новых тяжёлых assets не добавлено)
