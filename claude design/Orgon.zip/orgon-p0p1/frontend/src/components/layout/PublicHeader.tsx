// ============================================================
// PublicHeader v2 — landing chrome
// ============================================================
// Тонкий public header: wordmark + nav + CTA. Логотип не трогаем —
// используем существующий <LogoMark> компонент.
// ============================================================

"use client";

import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { LogoMark } from "@/components/brand/LogoMark";

const NAV = [
  { href: "/features", label: "Возможности" },
  { href: "/pricing",  label: "Тарифы" },
  { href: "/about",    label: "О компании" },
];

export function PublicHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-10 h-16 flex items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-3 -ml-1 px-1 py-1 hover:opacity-80 transition-opacity">
          <LogoMark />
        </Link>

        <nav className="hidden md:flex items-center gap-7">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className="text-[13px] text-muted-foreground hover:text-foreground transition-colors"
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="hidden sm:inline-block text-[13px] text-muted-foreground hover:text-foreground transition-colors"
          >
            Войти
          </Link>
          <Button variant="primary" size="sm" asChild>
            <Link href="/contact?topic=demo">Демо</Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
